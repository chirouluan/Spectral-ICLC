# 四批网页实验数据

每套目录仅使用同目录文件：预测时上传train.json、val.json、test.json，粘贴prompt.txt；模型读完参考直接预测完整val和test。保存输出为predictions.json。

评分时在原聊天上传val_labels.json、test_labels.json；另开聊天则再提供predictions.json和同一个prompt.txt。不要提前上传答案、metadata、私有映射或_provenance。每个Prompt有独立experiment_id，预测文件不可跨条件混用。

优先运行full_reference主实验：T1/T2使用全部合法源日90条参考，未见类别任务使用已见7类全部70条参考，公共数据使用其完整合法Train池（保留其中的技术重复记录）。k_1/k_3/k_5是补充的参考数量实验。T3按原计划使用源日5、目标日0/1/2/3/5及四个对照，不额外套乘K，也不增加full_reference。

K是每类显示的参考数，SNV+LDA或监督PLS使用的训练标签预算单独记录，不能称为STRICT-K。相同任务/repeat的full_reference与K条件共享同一个变换、完整Val/Test及记录顺序，只改变参考集合。训练参考文件不是训练集预测结果。

前三批：T1/T2共用相应源日Train拟合的LDA8；未见15%/30%单独用7类Train拟合LDA6；T3各条件共用源日5例/类（45条）锚点拟合的LDA8，目标日不拟合变换。T3 target_only仅指展示的参考，仍有源日45标签的表示监督。

第三批val仅14条已见样品，test完整36条（已见28、未见8），评分另给Seen/Unseen/H-mean。15%/30%不参与任何日期的Train/Val表示拟合或支持选择。

公共数据按逐数据文献方案，未统一改成LDA。Beef保留官方Test，其官方Train每类6条中留1条Val、5条Train以支持K=5；这与先前本地基线4/2的开发划分不同，不能直接混为同配置对照。蜂蜜保留Acquisition6 Test，每次在每产品Acquisition1–5中随机选1组作Val，其余Train；共享官方Test的五次实验不是五套新独立测试样品。

完整val和test各是一个JSON文件，没有切包或抽取小型评价子集；尤其蜂蜜文件较大，不能将网页未读完或输出截断算作完整有效结果。所有答案仍按完整评价集评分，缺失预测计错。

T3每repeat保留原计划19个目录，其中部分是相同参考的锚点重复；index.csv的equivalent_to标注其等价条件，分析时不得计成独立实验。公共姜黄两个任务共用70条光谱，不能算两套独立数据。

## 目录索引


- [第一批：三日期T1同日九分类](batch_01_T1/README.md)：60套。
- [第二批：三个T2方向及Day0→Day14的T3四组对照](batch_02_T2_T3/README.md)：155套。
- [第三批：联合留出15%/30%的未见类别识别](batch_03_unseen_15_30/README.md)：60套。
- [第四批：7套公共数据、8项分类任务](batch_04_public/README.md)：160套。

index.csv列出全部条件；_provenance保存分区、变换、拟合ID和原始文件哈希；validation_report.json为实际完整性检查。这里没有真实LLM预测或性能结果。

可用本地确定性评分核对网页算术：
```powershell
$env:PYTHONPATH = Join-Path (Get-Location) 'src'
& D:\Anaconda\envs\specllm\python.exe scripts/score_web_predictions.py --package '<当前实验目录>' --predictions '<predictions.json>' --output '<新评分文件.json>'
```
